<?php
require_once get_template_directory() . '/admin/functions.php';
require_once get_template_directory() . '/admin/register_sidebar.php';
require_once get_template_directory() . '/admin/redux.php';